create definer = root@localhost trigger pre_insert
    before insert
    on tbl_user_account
    for each row
BEGIN
    SET NEW.CreateTime = CURRENT_TIMESTAMP();
    SET NEW.ID_User = UUID();
END;

