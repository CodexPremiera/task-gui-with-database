create definer = root@localhost trigger pre_insert_todo
    before insert
    on tbl_todo
    for each row
BEGIN
    SET NEW.CreateTime = CURRENT_TIMESTAMP();
    SET NEW.ID_Todo = UUID();
END;

